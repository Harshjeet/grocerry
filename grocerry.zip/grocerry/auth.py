from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import current_user, login_user, logout_user, login_required
from .models import User
from . import db
from werkzeug.security import generate_password_hash, check_password_hash


auth = Blueprint('auth', __name__)

@auth.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')

        admin = User.query.filter_by(email=email, role="adminRole").first()

        if admin:
            if check_password_hash(admin.password, password):
                login_user(admin)
                flash("Admin login successful!", "success")
                return redirect(url_for('views.admin_dashboard'))
            else:
                flash("Invalid password.", "error")
        else:
            flash("No admin user with that Email.", "error")

    return render_template('admin_login.html')

@auth.route('/user-login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        name = request.form.get('name')

        user = User.query.filter_by(email= email, role="userRole").first()

        if user and user.role == "adminRole":
            flash("Admins should use the admin login page.", "warning")
            return redirect(url_for('auth.user_login'))

        if user and check_password_hash(user.password, password):
            login_user(user)
            flash("User Logged in successfully!", "success")
            return redirect(url_for('views.user_dashboard'))
        else:
            flash("Invalid name or password.", "error")

    return render_template('user_login.html')


@auth.route('/register', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        print(role)

        existing_user = User.query.filter_by(email=email).first()

        if existing_user:
            flash("An account with this email already exists.", "error")
        else:
            new_user = User(name=name, email=email, role=role)
            new_user.password = generate_password_hash(password)
            db.session.add(new_user)
            db.session.commit()

            
            if role == "adminRole":
                flash("Admin Account created successfully! You can now log in.", "success")
                return redirect(url_for('auth.admin_login'))
            else:
                flash("User Account created successfully! You can now log in.", "success")
                return redirect(url_for('auth.user_login'))

    return render_template('signup.html')






@auth.route('/logout')
def logout():
    flash("Logged out successfully!", "success")
    logout_user()
    
    return redirect(url_for('views.home'))
