from . import db
from flask_login import UserMixin
from datetime import date

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    email = db.Column(db.String(120), unique=True )
    password = db.Column(db.String(60) )
    role = db.Column(db.String(20))
    carts = db.relationship('Cart', backref='user', lazy=True)
    orders = db.relationship('Order', backref='user', lazy=True)


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100) )
    description = db.Column(db.Text )
    category = db.Column(db.String(50) )
    price = db.Column(db.Float )
    image = db.Column(db.String(255))
    manufacture_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date)
    carts = db.relationship('Cart', backref='product', lazy=True)
    quantity = db.Column(db.Integer)
    order_items = db.relationship('OrderItem', backref='product', lazy=True)

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id') )
    product_id = db.Column(db.Integer, db.ForeignKey('product.id') )
    quantity = db.Column(db.Integer )
    total_price = db.Column(db.Float )

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id') )
    order_date = db.Column(db.DateTime )
    total_amount = db.Column(db.Float )
    order_items = db.relationship('OrderItem', backref='order', lazy=True)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id') )
    product_id = db.Column(db.Integer, db.ForeignKey('product.id') )
    quantity = db.Column(db.Integer )
    item_price = db.Column(db.Float )
