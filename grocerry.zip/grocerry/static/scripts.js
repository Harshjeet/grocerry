.badge {
    background-color: #f44336; /* Red color */
    color: white;
    padding: 4px 8px;
    border-radius: 50%;
}