from flask import Blueprint, request, jsonify
from flask_restful import Resource, Api
from .models import Product
from . import db

api_bp = Blueprint('api', __name__)
api = Api(api_bp)

class ProductResource(Resource):
    def get(self, product_id=None):
        if product_id:
            product = Product.query.get(product_id)
            if product:
                return product.to_dict()
            return {"message": "Product not found"}, 404
        products = Product.query.all()
        return [product.to_dict() for product in products]
    
    def post(self):
        data = request.json
        product = Product(**data)
        db.session.add(product)
        db.session.commit()
        return product.to_dict(), 201

    def put(self, product_id):
        product = Product.query.get(product_id)
        if not product:
            return {"message": "Product not found"}, 404
        data = request.json
        for key, value in data.items():
            setattr(product, key, value)
        db.session.commit()
        return product.to_dict()

    def delete(self, product_id):
        product = Product.query.get(product_id)
        if not product:
            return {"message": "Product not found"}, 404
        db.session.delete(product)
        db.session.commit()
        return {"message": "Product deleted successfully"}, 204

class CategoryResource(Resource):
    def get(self, category_id=None):
        if category_id:
            category = Category.query.get(category_id)
            if category:
                return category.to_dict()
            return {"message": "Category not found"}, 404
        categories = Category.query.all()
        return [category.to_dict() for category in categories]

    # Implement the other CRUD methods for categories similarly to products
    # ...

# Add resources to the API
api.add_resource(ProductResource, '/api/products', '/api/products/<int:product_id>')
api.add_resource(CategoryResource, '/api/categories', '/api/categories/<int:category_id>')
