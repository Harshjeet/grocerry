from flask import Blueprint, render_template, request, flash, redirect, url_for,current_app
from flask_login import current_user, login_user, logout_user, login_required
from werkzeug.utils import secure_filename
from sqlalchemy import or_
import os
import secrets
from datetime import datetime
from . import create_app, db
from .forms import ProductForm
from .models import Product, Order, OrderItem, User, Cart

views = Blueprint('views', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_images(image):
    hash_photo = secrets.token_urlsafe(10)
    _, file_extension = os.path.splitext(image.filename)
    image_name = hash_photo + file_extension
    file_path = os.path.join(current_app.root_path, 'static/product_images', image_name)
    print(file_path)
    image.save(file_path)
    return image_name


@views.route('/')
@views.route('/home')
def home():
    return render_template('home.html')
    

# Define other routes for product display, cart, orders, etc.

@views.route('/admin-dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    products = Product.query.all()
    return render_template('admin_dashboard.html',name = current_user, products=products)

@views.route('/add-product', methods=['GET', 'POST'])
@login_required
def add_product():
    form = ProductForm()
    
    if form.validate_on_submit():
        image_name = save_images(form.image.data) if form.image.data else None
        product = Product(name=form.name.data, price=form.price.data, image=image_name, category=form.category.data, description=form.description.data, manufacture_date=form.manufacture_date.data, expiry_date=form.expiry_date.data)
        print("line52")
        db.session.add(product)
        db.session.commit()
        flash("Product added successfully!", "success")
        return redirect(url_for('views.admin_dashboard'))

    return render_template('add_product.html', form=form)

@views.route('/edit-product/<int:product_id>', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    edit_form = ProductForm(obj=product)

    if request.method == 'POST':
        if edit_form.validate_on_submit():
            edit_form.populate_obj(product)
            
            # will add image logic later
            #want to add logic to edit images
            
            
            db.session.commit()
            flash("Product updated successfully!", "success")
            return redirect(url_for('views.admin_dashboard'))

    return render_template('edit_product.html', edit_form=edit_form, product=product)

@views.route('/delete-product/<int:product_id>', methods=['POST'])
@login_required
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash("Product deleted successfully!", "success")
    return redirect(url_for('views.admin_dashboard'))


@views.route('/user-dashboard', methods=['GET', 'POST'])
def user_dashboard():
    products = Product.query.all()
    return render_template('user_dashboard.html',name = current_user, products=products)
 

@views.route('/add-to-cart', methods=['GET', 'POST'])
@login_required
def add_to_cart():
    product_id = request.args.get('product_id', type=int)
    quantity = request.args.get('quantity', default=1, type=int)
    
    product = Product.query.get_or_404(product_id)
    existing_cart_item = Cart.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    
    if existing_cart_item:
        existing_cart_item.quantity += quantity
        existing_cart_item.total_price = existing_cart_item.product.price * existing_cart_item.quantity
    else:
        cart_item = Cart(user_id=current_user.id, product_id=product_id, quantity=quantity, total_price=product.price * quantity)
        db.session.add(cart_item)
    
    db.session.commit()
    flash("Product added to cart!", "success")
    
    return redirect(url_for('views.cart'))


@views.route('/cart')
@login_required
def cart():
    cart_items = Cart.query.filter_by(user_id=current_user.id).all()
    print(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total_price=total_price)

@views.route('/remove-from-cart/<int:product_id>')
@login_required
def remove_from_cart(product_id):
    cart_item = Cart.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    if cart_item:
        db.session.delete(cart_item)
        db.session.commit()
        flash("Product removed from cart!", "success")
    return redirect(url_for('views.cart'))

@views.route('/buy', methods=['GET','POST'])
@login_required
def buy():
    user = current_user
    cart_items = Cart.query.filter_by(user_id=user.id).all()
    
    if not cart_items:
        flash("Your cart is empty.", "warning")
        return redirect(url_for('views.cart'))
    total_amount = sum(item.total_price for item in cart_items)
    
    # Create an Order
    order = Order(user_id=user.id, order_date=datetime.utcnow(), total_amount=total_amount)
    print(order)
    db.session.add(order)
    db.session.commit()
    for cart_item in cart_items:
        order_item = OrderItem(order_id=order.id, product_id=cart_item.product_id, quantity=cart_item.quantity, item_price=cart_item.product.price)
        db.session.add(order_item)
        db.session.delete(cart_item)
    db.session.commit()
    
    flash("Items purchased successfully!", "success")
    return redirect(url_for('views.order_history'))

@views.route('/order-history')
@login_required
def order_history():
    recent_purchases = OrderItem.query.join(Order).filter_by(user_id=User.id).order_by(Order.order_date.desc()).all() 
    return render_template('buy.html', recent_purchases=recent_purchases)

@views.route('/search-products', methods=['GET'])
def search_products():
    query = request.args.get('query')
    
    # Search products by name, category, manufacture date, and product name keywords
    products = Product.query.filter(
        or_(
            Product.name.ilike(f'%{query}%'),
            Product.category.ilike(f'%{query}%'),
            Product.manufacture_date.ilike(f'%{query}%'),
            Product.description.ilike(f'%{query}%')
        )
    ).all()
    
    return render_template('search_results.html', products=products, query=query, quantity=len(products))



@views.route('/demo', methods=['GET', 'POST'])
def demo():
    return render_template('demo.html')