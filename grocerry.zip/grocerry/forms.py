from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, FileField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Length
from flask_wtf.file import FileField
from wtforms.fields import DateField, IntegerField

class ProductForm(FlaskForm):
    name = StringField('Product Name', validators=[DataRequired()])
    price = FloatField('Price', validators=[DataRequired()])
    image = FileField('Product Image')
    category = SelectField('Category', choices=[('fruits', 'Fruits'), ('vegetables', 'Vegetables'), ('snacks', 'Snacks')], validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    edit_image = FileField('Edit Product Image')
    manufacture_date = DateField('Manufacture Date')
    expiry_date = DateField('Expiry Date')
    quantity = IntegerField('Quantity')